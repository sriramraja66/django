from django import forms
from .models import AddItem

class ItemForm(forms.ModelForm):
    class Meta:
        model = AddItem
        fields = ['item_name','item_dese','item_discount','item_price','item_image']