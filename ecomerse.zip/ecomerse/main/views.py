from django.shortcuts import render,redirect
from .models import AddItem
from .forms import ItemForm
from django.views.generic.edit import CreateView
from django.core.paginator import Paginator
# Create your views here.
def index(request):
    item_list = AddItem.objects.all()
    # serch
    item_name = request.GET.get('item_name')

    if item_name !='' and item_name is not None:
        item_list = item_list.filter(item_name__icontains=item_name)

    paginator = Paginator(item_list,8)
    page = request.GET.get('page')

    item_list = paginator.get_page(page)
    return render(request,'main/index.html',{'items':item_list})

# createitem class based for summa
class create_item(CreateView):
    model = AddItem
    fields = ['item_name','item_dese','item_discount','item_price','item_image']
    template_name='main/add_item.html'
    def form_valid(self,form):
        form.instance.user_name = self.request.user

        return super().form_valid(form)


def add_item(request):
    form = ItemForm(request.POST or None)
    
    if form.is_valid():
        form.save()
        return redirect('index')

    return render(request,'main/add_item.html',{'form':form})

def detail(request,id):
    item_list = AddItem.objects.get(pk=id)
    return render(request,'main/detail.html',{'item':item_list})