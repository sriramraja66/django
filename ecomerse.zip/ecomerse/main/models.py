from django.db import models
from django.contrib.auth.models import User
# Create your models here.
from django.urls import reverse
class AddItem(models.Model):
    
    user_name = models.ForeignKey(User,on_delete=models.CASCADE,default=1)
    item_name = models.CharField(max_length=200)
    item_dese = models.TextField(max_length=500)
    item_discount = models.IntegerField()
    item_price = models.IntegerField()
    item_image = models.URLField(default='https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/1200px-No_image_available.svg.png')

    def __str__(self):
        return self.item_name

    def get_absolute_url(self):
        return reverse('detail',kwargs={'id':self.pk})