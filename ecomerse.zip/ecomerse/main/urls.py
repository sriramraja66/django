from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('additem',views.create_item.as_view(),name='add_item'),
    path('detail/<int:id>/',views.detail,name='detail'),
]